#!/bin/bash
# =============================================================================
# smoke-test.sh — Kiểm tra nhanh OLLVM TRƯỚC khi build thật
#
# Kiểm tra 4 điều:
#   A. File .m app (ngoài XPF) qua cc-wrapper -> brew clang + Hikari:
#      - biên dịch được với SDK iphoneos
#      - log có "Running Hikari On" (plugin nạp + chạy)
#      - log có ">>>> run" (policy match hàm)
#      - nếu -O0 không kích hoạt plugin -> tự chuyển GCC_OPTIMIZATION_LEVEL=s
#   A2. Mô phỏng đúng dạng lệnh Xcode Debug thật: target arm64e + cờ Apple-only
#      "-index-store-path <dir>" — wrapper PHẢI lọc bỏ cờ này trước khi gọi
#      brew clang (hồi quy cho run #2: unknown argument -> BUILD FAILED)
#   B. File .c nằm trong Cofi/XPF/ -> Apple clang, KHÔNG có Hikari
#   C. Chuỗi nhạy cảm trong binary smoke đã bị strenc mã hoá
#
# Yêu cầu môi trường: OLLVM_LLVM_HOME, OLLVM_HIKARI_PLUGIN (do setup-ollvm.sh)
# =============================================================================
set -euo pipefail

cd "${GITHUB_WORKSPACE:-$PWD}"

BREW_LLVM="${OLLVM_LLVM_HOME:?cần OLLVM_LLVM_HOME (chạy setup-ollvm.sh trước)}"
PLUGIN="${OLLVM_HIKARI_PLUGIN:?cần OLLVM_HIKARI_PLUGIN (chạy setup-ollvm.sh trước)}"

SDK=$(xcrun --sdk iphoneos --show-sdk-path)
SMOKE_DIR=$(mktemp -d)
trap 'rm -rf "$SMOKE_DIR"' EXIT

cat > "$SMOKE_DIR/app_probe.m" <<'EOF'
#import <Foundation/Foundation.h>
@interface OllvmSmoke @end
@implementation OllvmSmoke
- (NSString *)secret {
    NSString *s = @"dsw_ollvm_smoke_secret_marker";
    return [NSString stringWithFormat:@"[%@]", s];
}
@end
EOF

echo "--- A. Compile nguồn app arm64 (kỳ vọng: brew clang + Hikari, cờ Apple-only bị lọc) ---"
run_app_smoke() { # $1 = mức tối ưu, $2 = file log
    local opt="$1" log="$2"
    local rc=0
    # -index-store-path: cờ Apple-only — run #2 brew clang chết "unknown argument";
    # từ run #11 arm64 là đường brew clang DUY NHẤT nên đặt filter probe vào đây
    "$PWD/ollvm/cc-wrapper.sh" -x objective-c -fobjc-arc "$opt" \
        -target arm64-apple-ios17.0 -isysroot "$SDK" \
        -index-store-path "$SMOKE_DIR/idxstore_khong_ton_tai" \
        -c "$SMOKE_DIR/app_probe.m" -o "$SMOKE_DIR/app_probe.o" 2>&1 | tee "$log" || rc=1
    return $rc
}

if ! run_app_smoke -O0 "$SMOKE_DIR/smoke_o0.log"; then
    echo "::error::Biên dịch smoke bằng brew clang THẤT BẠI (xem log trên — thường do SDK/clang version lệch nhau, thử đổi OLLVM_LLVM_VERSION hoặc XCODE_PREFER)"
    exit 1
fi

if grep -q "Running Hikari On" "$SMOKE_DIR/smoke_o0.log"; then
    echo "    OK: Hikari chạy được ở -O0 (giữ nguyên Debug không cần chỉnh gì)"
    RUN_LOG="$SMOKE_DIR/smoke_o0.log"
    WORKING_OPT="-O0"
else
    echo "    ::warning:: Plugin không kích hoạt ở -O0 — thử -Os và tự thêm GCC_OPTIMIZATION_LEVEL=s"
    if ! run_app_smoke -Os "$SMOKE_DIR/smoke_os.log"; then
        echo "::error::Biên dịch smoke -Os THẤT BẠI"
        exit 1
    fi
    if ! grep -q "Running Hikari On" "$SMOKE_DIR/smoke_os.log"; then
        echo "::error::Plugin KHÔNG chạy cả ở -Os — kiểm tra build plugin / phiên bản LLVM"
        exit 1
    fi
    echo "GCC_OPTIMIZATION_LEVEL=s" > "$PWD/ollvm/build/ollvm-env-extra.txt"
    echo "    Đã ghi OLLVM_EXTRA_XCODEBUILD_ARGS=GCC_OPTIMIZATION_LEVEL=s"
    RUN_LOG="$SMOKE_DIR/smoke_os.log"
    WORKING_OPT="-Os"
fi

if ! grep -q ">>>> run" "$RUN_LOG"; then
    echo "::error::Policy KHÔNG match hàm nào (thiếu '>>>> run' trong log) — kiểm tra ollvm/policy.json"
    exit 1
fi
if grep -q "unknown argument" "$RUN_LOG"; then
    echo "::error::Cờ Apple-only (-index-store-path) lọt tới brew clang ở đường arm64 — kiểm tra filter_apple_only_flags trong cc-wrapper.sh"
    exit 1
fi
echo "    OK: arm64 brew clang + Hikari + lọc -index-store-path"
if grep -q "Error: conf not found" "$RUN_LOG"; then
    echo "::error::policy.json KHÔNG được nạp — kiểm tra thư mục đặt policy"
    exit 1
fi
echo "    OK: policy match, các pass đã chạy"

if grep -q "could not find policy" "$RUN_LOG"; then
    echo "::error::policy.json tham chiếu tên policy không tồn tại trong policy_map"
    exit 1
fi

echo "--- A2. Hồi quy run #10: lệnh Xcode Debug arm64e (kỳ vọng MỚI: Apple clang, KHÔNG Hikari) ---"
# Run #2 fail tại điểm này vì cờ Apple-only; run #10 fail vì brew llvm@19 phát
# sinh object arm64e ABI CŨ (arm64e.old) bị ld64 Xcode 16.4 từ chối. Từ run #11
# wrapper điều hướng TOÀN BỘ compile arm64e sang Apple clang (hiểu cả cờ
# Apple-only) — marker "[ollvm] arm64e slice -> Apple clang" phải hiện trong log.
mkdir -p "$SMOKE_DIR/idxstore_arm64e"  # Apple clang nhận cờ nguyên bản -> dir phải tồn tại
RC_IDX=0
"$PWD/ollvm/cc-wrapper.sh" -x objective-c -fobjc-arc -fobjc-weak "$WORKING_OPT" \
    -target arm64e-apple-ios17.0 -isysroot "$SDK" \
    -index-store-path "$SMOKE_DIR/idxstore_arm64e" \
    -c "$SMOKE_DIR/app_probe.m" -o "$SMOKE_DIR/app_probe_arm64e.o" 2>&1 \
    | tee "$SMOKE_DIR/smoke_idx.log" || RC_IDX=1
if [ "$RC_IDX" != "0" ] || [ ! -f "$SMOKE_DIR/app_probe_arm64e.o" ]; then
    echo "::error::Probe arm64e THẤT BẠI — Apple clang không compile được (kiểm tra xcode-select / SDK)"
    exit 1
fi
if ! grep -q "arm64e slice -> Apple clang" "$SMOKE_DIR/smoke_idx.log"; then
    echo "::error::arm64e KHÔNG được điều hướng sang Apple clang (thiếu marker '[ollvm] arm64e slice -> Apple clang') — chạy lại sẽ chết ở ld: arm64e.old (run #10)"
    exit 1
fi
if grep -q "Running Hikari On" "$SMOKE_DIR/smoke_idx.log"; then
    echo "::error::Hikari vẫn chạy trên slice arm64e — sẽ sinh object arm64e.old bị ld64 từ chối (run #10)"
    exit 1
fi
echo "    OK: arm64e -> Apple clang (marker hiện, không Hikari, không lỗi cờ Apple-only)"

echo "--- B. Compile nguồn XPF (kỳ vọng: Apple clang, KHÔNG Hikari) ---"
XPF_DIR="$PWD/Cofi/XPF"
if [ -d "$XPF_DIR" ]; then
    PROBE="$XPF_DIR/ollvm_probe_tmp.c"
    echo "int ollvm_xpf_probe(void) { return 42; }" > "$PROBE"
    RC=0
    "$PWD/ollvm/cc-wrapper.sh" -target arm64-apple-ios17.0 -isysroot "$SDK" \
        -c "$PROBE" -o "$SMOKE_DIR/xpf_probe.o" 2>&1 | tee "$SMOKE_DIR/xpf.log" || RC=1
    rm -f "$PROBE"
    if [ "$RC" != "0" ] || [ ! -f "$SMOKE_DIR/xpf_probe.o" ]; then
        echo "::error::Probe XPF không biên dịch được bằng Apple clang"
        exit 1
    fi
    if grep -q "Running Hikari On" "$SMOKE_DIR/xpf.log"; then
        echo "::error::File XPF bị route qua Hikari (SAI) — kiểm tra logic case trong cc-wrapper.sh"
        exit 1
    fi
    echo "    OK: XPF -> Apple clang (build XPF giữ nguyên)"
else
    echo "    (thiếu Cofi/XPF — bỏ qua probe B; trên GitHub repo XPF tồn tại thì probe sẽ chạy)"
fi

echo "--- C. strenc trên binary smoke ---"
if [ -f "$SMOKE_DIR/app_probe.o" ]; then
    if strings "$SMOKE_DIR/app_probe.o" 2>/dev/null | grep -q "dsw_ollvm_smoke_secret_marker"; then
        echo "    ::warning:: Chuỗi smoke vẫn thấy rõ trong .o (strenc có thể bỏ qua GV dùng chung nhiều hàm)"
    else
        echo "    OK: chuỗi nhạy cảm đã được strenc mã hoá"
    fi
fi

echo "==> SMOKE TEST PASS"
