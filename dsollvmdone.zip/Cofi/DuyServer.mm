//
//  DuyServer.mm — License Core V2 (server-authoritative signed lease).
//
//  Nội dung (PHASE 1 — đã LOẠI toàn bộ anti-tamper cũ: q1..q5 token store,
//  mirror vk4, watchdog canary, IMP baseline, env/dyld/debug probes,
//  multi-path exit, marker dy9, constructor reassert — theo yêu cầu
//  "xoá anti cũ, chỉ nâng cấp phần key cho mạnh"; anti sẽ thêm ở phase 2):
//
//    1. Cặp khóa thiết bị EC P-256 — Secure Enclave (A12+) với fallback
//       software key ThisDeviceOnly. Private key KHÔNG rời thiết bị;
//       server chỉ thấy public key (proof-of-possession).
//    2. Keychain cho license key (thay NSUserDefaults) + migrate dữ liệu cũ.
//    3. Parse public key server (PEM SPKI P-256 → SecKey).
//    4. Sinh nonce CSPRNG + build request V2 (nonce, timestamp, pop).
//    5. Verify phản hồi: chữ ký ECDSA-SHA256 DER + pv + action + nonce echo
//       + server_time + sequence + license_fp + device_binding + expiry.
//       Client CHỈ tin giá trị đọc từ chuỗi ký `sig_input`.
//    6. Security state machine — transition bảng trắng, BOOT→AUTHORIZED
//       bị reject.
//
//  KHÔNG block main thread. KHÔNG exit() trong file này. Fail-closed.
//

#import "DuyServer.h"
#import "HeaderAPI.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <stdlib.h>
#import <stdio.h>
#import <string.h>

#pragma mark - Constants

static NSString *const kKeychainService   = @"com.dswunity.license.v2";
static NSString *const kKeychainAccount   = @"license.key";
static NSString *const kDeviceKeyTag      = @"com.dswunity.license.devicekey.v2";

/* Giới hạn đồng hồ — lease được coi còn hạn nếu expires_at > now - skew */
static const int64_t kClockSkewLeaseSec   = 60;
/* server_time phải nằm trong khoảng hợp lý này so với local */
static const int64_t kMaxReasonableDrift  = 86400;   /* 1 ngày */

/* kPackageToken sau khi cắt khoảng trắng/dòng mới (chống lỗi dán token
 * có \n phía sau — server regex nghiêm ngặt 32 hex sẽ từ chối). */
static NSString *kdy_package_token(void) {
    static NSString *tok = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tok = [[kPackageToken stringByTrimmingCharactersInSet:
                [NSCharacterSet whitespaceAndNewlineCharacterSet]] lowercaseString];
    });
    return tok;
}

#pragma mark - LicenseStateName

NSString *LicenseStateName(LicenseState s) {
    switch (s) {
        case LicenseStateBoot:           return @"BOOT";
        case LicenseStateNetInit:        return @"NET_INIT";
        case LicenseStateChallenge:      return @"CHALLENGE";
        case LicenseStateKeyPending:     return @"KEY_PENDING";
        case LicenseStateAuthenticating: return @"AUTHENTICATING";
        case LicenseStateAuthorized:     return @"AUTHORIZED";
        case LicenseStateRenewing:       return @"RENEWING";
        case LicenseStateGrace:          return @"GRACE";
        case LicenseStateRevoked:        return @"REVOKED";
        case LicenseStateExpired:        return @"EXPIRED";
        case LicenseStateLocked:         return @"LOCKED";
        case LicenseStateShutdown:       return @"SHUTDOWN";
    }
    return @"?";
}

#pragma mark - Small helpers (C, không phụ thuộc ObjC runtime)

static NSString *kdy_hex(const uint8_t *buf, size_t len) {
    static const char hexc[] = "0123456789abcdef";
    char out[129];
    if (len > 64) len = 64;
    for (size_t i = 0; i < len; i++) {
        out[i * 2]     = hexc[buf[i] >> 4];
        out[i * 2 + 1] = hexc[buf[i] & 0xF];
    }
    out[len * 2] = 0;
    return [NSString stringWithUTF8String:out];
}

static NSString *kdy_b64(NSData *data) {
    return [data base64EncodedStringWithOptions:0];
}

static NSData *kdy_b64decode(NSString *s) {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return nil;
    return [[NSData alloc] initWithBase64EncodedString:s
                                               options:NSDataBase64DecodingIgnoreUnknownCharacters];
}

/* So sánh chuỗi constant-time (chống timing leak — lớp phụ) */
static BOOL kdy_cteq(NSString *a, NSString *b) {
    NSData *da = [a dataUsingEncoding:NSUTF8StringEncoding];
    NSData *db = [b dataUsingEncoding:NSUTF8StringEncoding];
    NSUInteger la = da.length, lb = db.length;
    uint8_t diff = (uint8_t)(la ^ lb);
    NSUInteger n = MAX(la, lb);
    const uint8_t *pa = (const uint8_t *)da.bytes;
    const uint8_t *pb = (const uint8_t *)db.bytes;
    for (NSUInteger i = 0; i < n; i++) {
        uint8_t x = (i < la) ? pa[i] : 0;
        uint8_t y = (i < lb) ? pb[i] : 0;
        diff |= (uint8_t)(x ^ y);
    }
    return diff == 0;
}

static BOOL kdy_isHexLower(NSString *s, NSUInteger wantLen) {
    if (s.length != wantLen) return NO;
    const char *c = s.UTF8String;
    for (NSUInteger i = 0; i < wantLen; i++) {
        char ch = c[i];
        if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f'))) return NO;
    }
    return YES;
}

static int64_t kdy_now_sec(void) {
    return (int64_t)[[NSDate date] timeIntervalSince1970];
}

#pragma mark - LicenseLease

@interface LicenseLease ()
@property (nonatomic, copy, readwrite) NSString *sessionId;
@property (nonatomic, assign, readwrite) int64_t issuedAt;
@property (nonatomic, assign, readwrite) int64_t expiresAt;
@property (nonatomic, assign, readwrite) uint32_t sequence;
@property (nonatomic, copy, readwrite) NSString *licenseFp;
@property (nonatomic, copy, readwrite) NSString *deviceBinding;
@property (nonatomic, assign, readwrite) int64_t serverTime;
@property (nonatomic, assign, readwrite) int64_t clockOffset;
@property (nonatomic, assign, readwrite) int64_t leaseTtl;
@property (nonatomic, assign, readwrite) int64_t graceTtl;
@property (nonatomic, copy, readwrite) NSString *expiry;
@property (nonatomic, assign, readwrite) NSInteger daysLeft;
@property (nonatomic, copy, readwrite) NSString *contact;
@property (nonatomic, strong, readwrite, nullable) NSDictionary *permissions;
/* Task 17 — offset payload đã verify (chỉ tồn tại trên phản hồi action=offsets) */
@property (nonatomic, copy, readwrite, nullable) NSString *offsetsJSON;
@property (nonatomic, copy, readwrite, nullable) NSString *gameVersion;
@property (nonatomic, copy, readwrite, nullable) NSString *nonceS;
@property (nonatomic, assign, readwrite) BOOL maintenance;
@property (nonatomic, assign, readwrite) BOOL forceExit;
@end

@implementation LicenseLease

- (BOOL)isValidNowWithClockSkew:(int64_t)skew {
    int64_t now = kdy_now_sec() + self.clockOffset;
    return (self.expiresAt + skew) > now;
}

@end

#pragma mark - LicenseCore

@interface LicenseCore ()
@property (nonatomic, strong) dispatch_queue_t stateQueue;
@property (nonatomic, assign) LicenseState state;
@property (nonatomic, strong, nullable) LicenseLease *lease;
@property (nonatomic, assign) int64_t clockOffset;      /* hiệu chỉnh trung bình */
@property (nonatomic, assign) BOOL migrated;
/* Lý do verify Invalid gần nhất — hiển thị cho user (RELEASE luôn có) */
@property (nonatomic, copy, readwrite, nullable) NSString *lastVerifyFailHint;
@end

@implementation LicenseCore {
    SecKeyRef _deviceKey;
    SecKeyRef _serverKey;
    BOOL _serverKeyFailed;
    BOOL _deviceKeyFailed;
}

+ (instancetype)sharedCore {
    static LicenseCore *inst = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        inst = [[LicenseCore alloc] init];
    });
    return inst;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _state = LicenseStateBoot;
        _stateQueue = dispatch_queue_create("com.dswunity.license.state", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

#pragma mark State machine

/* Bảng transition hợp lệ — mọi thứ khác đều bị reject. */
static BOOL kdy_transition_allowed(LicenseState from, LicenseState to) {
    if (from == to) {
        /* tự retry (NET_INIT→NET_INIT, AUTHENTICATING→AUTHENTICATING,
         * RENEWING→RENEWING, GRACE→GRACE) được phép */
        return from == LicenseStateNetInit || from == LicenseStateAuthenticating
            || from == LicenseStateRenewing || from == LicenseStateGrace;
    }
    if (from == LicenseStateShutdown) return NO;    /* terminal */
    switch (from) {
        case LicenseStateBoot:
            return to == LicenseStateNetInit || to == LicenseStateShutdown;
        case LicenseStateNetInit:
            /* FIX BUG đá về màn nhập key: NET_INIT→AUTHENTICATING phải hợp lệ.
             * Boot auto-login (hello OK + key đã lưu) gọi checkKey khi state
             * vẫn là NET_INIT — nhánh "không có key" mới chuyển KEY_PENDING.
             * Thiếu transition này: authenticating bị reject âm thầm (return
             * value bị bỏ qua) → auth vẫn chạy, lease vẫn accept, nhưng
             * AUTHORIZED cũng bị reject → state kẹt NET_INIT → gate_dismiss
             * chặn mãi → user bị đá về màn nhập key sau mỗi lần "kích hoạt
             * thành công". */
            return to == LicenseStateChallenge || to == LicenseStateKeyPending
                || to == LicenseStateAuthenticating || to == LicenseStateShutdown;
        case LicenseStateChallenge:
            return to == LicenseStateNetInit || to == LicenseStateKeyPending
                || to == LicenseStateAuthenticating || to == LicenseStateShutdown;
        case LicenseStateKeyPending:
            return to == LicenseStateAuthenticating || to == LicenseStateShutdown;
        case LicenseStateAuthenticating:
            /* BOOT→AUTHORIZED phải qua đây — transition trực tiếp bị reject */
            return to == LicenseStateAuthorized || to == LicenseStateKeyPending
                || to == LicenseStateChallenge || to == LicenseStateNetInit
                || to == LicenseStateShutdown;
        case LicenseStateAuthorized:
            return to == LicenseStateRenewing || to == LicenseStateGrace
                || to == LicenseStateRevoked || to == LicenseStateExpired
                || to == LicenseStateLocked || to == LicenseStateKeyPending
                || to == LicenseStateShutdown;
        case LicenseStateRenewing:
            return to == LicenseStateAuthorized || to == LicenseStateGrace
                || to == LicenseStateRevoked || to == LicenseStateExpired
                || to == LicenseStateLocked || to == LicenseStateKeyPending
                || to == LicenseStateShutdown;
        case LicenseStateGrace:
            return to == LicenseStateRenewing || to == LicenseStateAuthorized
                || to == LicenseStateLocked || to == LicenseStateKeyPending
                || to == LicenseStateRevoked || to == LicenseStateExpired
                || to == LicenseStateShutdown;
        case LicenseStateRevoked:
        case LicenseStateExpired:
            return to == LicenseStateKeyPending || to == LicenseStateAuthenticating
                || to == LicenseStateShutdown;
        case LicenseStateLocked:
            return to == LicenseStateKeyPending || to == LicenseStateAuthenticating
                || to == LicenseStateNetInit || to == LicenseStateShutdown;
        case LicenseStateShutdown:
            return NO;
    }
    return NO;
}

- (BOOL)transitionTo:(LicenseState)to {
    __block BOOL ok = NO;
    dispatch_sync(_stateQueue, ^{
        /* Dùng ivar trực tiếp — self.state getter cũng dispatch_sync
         * trên chính queue này → dùng getter ở đây sẽ DEADLOCK. */
        ok = kdy_transition_allowed(self->_state, to);
        if (ok) {
            self->_state = to;
        }
    });
    if (!ok) {
        [LicenseCore diag:@"[LICENSE] transition reject: %@ -> %@", LicenseStateName(self.state), LicenseStateName(to)];
    }
    return ok;
}

/* FIX BUG đá về màn nhập key (lớp phòng vệ 2): bắt buộc về AUTHORIZED sau khi
 * auth/renew được Granted + lease đã accept (chữ ký đã verify). Chỉ gọi SAU
 * verifyResponse == Granted — không phải cửa xác thực, chỉ là hồi phục
 * book-keeping khi bảng transition thiếu cạnh. Thử trực tiếp, rồi qua chuỗi
 * trung gian hợp lệ KEY_PENDING → AUTHENTICATING → AUTHORIZED (chạy được
 * từ mọi state trừ Boot/Shutdown). */
- (BOOL)ensureAuthorized {
    if (self.state == LicenseStateAuthorized) return YES;
    if ([self transitionTo:LicenseStateAuthorized]) return YES;
    [LicenseCore diag:@"[LICENSE] ensureAuthorized: hồi phục state qua chuỗi trung gian (state=%@)",
        LicenseStateName(self.state)];
    [self transitionTo:LicenseStateKeyPending];
    [self transitionTo:LicenseStateAuthenticating];
    BOOL ok = [self transitionTo:LicenseStateAuthorized];
    if (!ok) {
        [LicenseCore diag:@"[LICENSE] ensureAuthorized THẤT BẠI (state=%@) — gate_dismiss sẽ chặn",
            LicenseStateName(self.state)];
    }
    return ok;
}

- (LicenseState)state {
    __block LicenseState s;
    dispatch_sync(_stateQueue, ^{
        s = self->_state;
    });
    return s;
}

- (nullable LicenseLease *)currentLease {
    __block LicenseLease *l;
    dispatch_sync(_stateQueue, ^{
        l = self.lease;
    });
    return l;
}

- (void)acceptLease:(LicenseLease *)lease {
    dispatch_sync(_stateQueue, ^{
        self.lease = lease;
        self.clockOffset = lease.clockOffset;
    });
}

- (void)clearLease {
    dispatch_sync(_stateQueue, ^{
        self.lease = nil;
    });
}

- (int64_t)serverAlignedNow {
    __block int64_t offset = 0;
    dispatch_sync(_stateQueue, ^{
        offset = self.clockOffset;
    });
    return kdy_now_sec() + offset;
}

- (BOOL)sessionUsable {
    LicenseState s = self.state;
    if (s != LicenseStateAuthorized && s != LicenseStateRenewing && s != LicenseStateGrace) {
        return NO;
    }
    /* GRACE vẫn dùng được — server đã cấp lease + grace có chữ ký */
    LicenseLease *l = self.currentLease;
    if (!l) return NO;
    int64_t deadline = l.expiresAt + l.graceTtl;   /* hard grace do server ký */
    return (self.serverAlignedNow + kClockSkewLeaseSec) < deadline;
}

/* FIX lockout lớp 3 — chỉ dùng cho gate_dismiss hồi phục state kẹt:
 * lease (đã verify chữ ký lúc accept) còn hạn hay không, BẤT CHẤP state.
 * Không thay thế sessionUsable (cửa chuẩn); không hồi phục khi lease rỗng. */
- (BOOL)leaseAliveIgnoringState {
    LicenseLease *l = self.currentLease;
    if (!l) return NO;
    int64_t deadline = l.expiresAt + l.graceTtl;
    return (self.serverAlignedNow + kClockSkewLeaseSec) < deadline;
}

#pragma mark Device keypair (Secure Enclave + fallback)

- (nullable SecKeyRef)loadOrCreateDeviceKey {
    if (_deviceKeyFailed) return NULL;
    if (_deviceKey) {
        CFRetain(_deviceKey);
        return _deviceKey;
    }

    NSData *tag = [kDeviceKeyTag dataUsingEncoding:NSUTF8StringEncoding];

    /* Dictionary kiểm tra persistence — dùng lại cho self-check sau khi sinh key */
    NSDictionary *load = @{
        (__bridge id)kSecClass:             (__bridge id)kSecClassKey,
        (__bridge id)kSecAttrApplicationTag: tag,
        (__bridge id)kSecAttrKeyType:      (__bridge id)kSecAttrKeyTypeECSECPrimeRandom,
        (__bridge id)kSecReturnRef:        @YES,
        (__bridge id)kSecMatchLimit:       (__bridge id)kSecMatchLimitOne,
    };
    SecKeyRef found = NULL;
    OSStatus st = SecItemCopyMatching((__bridge CFDictionaryRef)load, (CFTypeRef *)&found);
    if (st == errSecSuccess && found != NULL) {
        _deviceKey = found;    /* sở hữu reference từ query */
        CFRetain(_deviceKey);
        [LicenseCore diag:@"[LICENSE] device key: nạp lại từ keychain (persistent ✓)"];
        return _deviceKey;
    }

    /* 2. Sinh mới — Secure Enclave trước (private key không thể export) */
    NSDictionary *seAttrs = @{
        (__bridge id)kSecClass:             (__bridge id)kSecClassKey,
        (__bridge id)kSecAttrTokenID:       (__bridge id)kSecAttrTokenIDSecureEnclave,
        (__bridge id)kSecAttrKeyType:       (__bridge id)kSecAttrKeyTypeECSECPrimeRandom,
        (__bridge id)kSecAttrKeySizeInBits: @256,
        (__bridge id)kSecAttrCanSign:       @YES,
        (__bridge id)kSecAttrCanVerify:     @NO,
        (__bridge id)kSecAttrApplicationTag: tag,
        (__bridge id)kSecAttrAccessible:    (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        (__bridge id)kSecReturnRef:         @YES,
    };
    CFErrorRef err = NULL;
    SecKeyRef key = SecKeyCreateRandomKey((__bridge CFDictionaryRef)seAttrs, &err);
    if (key != NULL) {
        /* FIX BUG "nhập key lần đầu vô được, out vào lại bị đá về màn nhập key":
         * nếu key SE không được lưu vào keychain (không persistent) thì mỗi
         * lần chạy app sinh key MỚI → device_pub đổi → server trả
         * 'Device mismatch' → client xóa key lưu → khóa vĩnh viễn.
         * Self-check: query lại keychain NGAY sau khi sinh — không tìm thấy
         * thì key này sẽ không sống sót qua restart → bỏ, dùng software key. */
        SecKeyRef probe = NULL;
        if (SecItemCopyMatching((__bridge CFDictionaryRef)load, (CFTypeRef *)&probe) == errSecSuccess
            && probe != NULL) {
            CFRelease(probe);   /* chỉ kiểm tra — ref chính là `key` đang giữ */
            _deviceKey = key;
            CFRetain(_deviceKey);
            [LicenseCore diag:@"[LICENSE] device key: Secure Enclave P-256 (persistent ✓)"];
            return _deviceKey;
        }
        [LicenseCore diag:@"[LICENSE] SE key KHÔNG persistent — chuyển sang software key"];
        CFRelease(key);
        key = NULL;
    }
    if (err != NULL) {
        [LicenseCore diag:@"[LICENSE] Secure Enclave unavailable (%ld) — fallback software key", (long)CFErrorGetCode(err)];
        CFRelease(err);
        err = NULL;
    }

    /* 3. Fallback: software key trong Keychain, ThisDeviceOnly */
    NSDictionary *swAttrs = @{
        (__bridge id)kSecClass:             (__bridge id)kSecClassKey,
        (__bridge id)kSecAttrKeyType:       (__bridge id)kSecAttrKeyTypeECSECPrimeRandom,
        (__bridge id)kSecAttrKeySizeInBits: @256,
        (__bridge id)kSecAttrCanSign:       @YES,
        (__bridge id)kSecAttrApplicationTag: tag,
        (__bridge id)kSecAttrAccessible:    (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        (__bridge id)kSecAttrIsPermanent:   @YES,
        (__bridge id)kSecReturnRef:         @YES,
    };
    key = SecKeyCreateRandomKey((__bridge CFDictionaryRef)swAttrs, &err);
    if (key != NULL) {
        /* Self-check persistence cho software key — nếu vẫn không lưu được
         * (keychain hỏng/thiếu entitlement) thì còn log để chẩn đoán thay
         * vì im lặng sinh key mới mỗi lần chạy. */
        SecKeyRef probe = NULL;
        if (SecItemCopyMatching((__bridge CFDictionaryRef)load, (CFTypeRef *)&probe) == errSecSuccess
            && probe != NULL) {
            CFRelease(probe);
            [LicenseCore diag:@"[LICENSE] device key: software P-256 (persistent ✓)"];
        } else {
            [LicenseCore diag:@"[LICENSE] device key: software P-256 (⚠ KHÔNG persistent — lần sau sẽ Device mismatch)"];
        }
        _deviceKey = key;
        CFRetain(_deviceKey);
        return _deviceKey;
    }
    if (err != NULL) {
        [LicenseCore diag:@"[LICENSE] device key create FAILED (%ld)", (long)CFErrorGetCode(err)];
        CFRelease(err);
    }
    _deviceKeyFailed = YES;
    return NULL;
}

- (nullable NSString *)devicePublicKeyB64 {
    SecKeyRef priv = [self loadOrCreateDeviceKey];
    if (!priv) return nil;
    SecKeyRef pub = SecKeyCopyPublicKey(priv);
    CFRelease(priv);                          /* nhả ref của caller */
    if (!pub) return nil;
    CFDataRef rawRef = SecKeyCopyExternalRepresentation(pub, NULL);
    CFRelease(pub);
    if (!rawRef) return nil;
    NSData *raw = CFBridgingRelease(rawRef);
    if (raw.length != 65) {
        return nil;
    }
    return kdy_b64(raw);   /* base64 điểm 04||X||Y — server bọc SPKI khi verify */
}

- (nullable NSString *)deviceBindingHex {
    NSString *pubB64 = [self devicePublicKeyB64];
    if (!pubB64) return nil;
    /* 16 hex đầu của SHA256("dev:" + pub_b64) — khớp LicenseApi::deviceBinding */
    const char *prefix = "dev:";
    NSMutableData *buf = [NSMutableData dataWithLength:CC_SHA256_DIGEST_LENGTH];
    CC_SHA256_CTX ctx;
    CC_SHA256_Init(&ctx);
    CC_SHA256_Update(&ctx, prefix, (CC_LONG)strlen(prefix));
    CC_SHA256_Update(&ctx, pubB64.UTF8String, (CC_LONG)strlen(pubB64.UTF8String));
    CC_SHA256_Final((uint8_t *)buf.mutableBytes, &ctx);
    /* FIX BUG device_binding mismatch: LicenseApi::deviceBinding (PHP) trả
     * substr(hex, 0, 16) = 16 KÝ TỰ HEX = 8 byte đầu. Bản cũ encode 16 BYTE
     * (32 hex) → không bao giờ khớp → mọi auth success đều bị từ chối với
     * hint "device_binding không khớp thiết bị này". */
    return kdy_hex((const uint8_t *)buf.bytes, 8);
}

- (nullable NSString *)signPop:(NSString *)message {
    SecKeyRef priv = [self loadOrCreateDeviceKey];
    if (!priv || !message) return nil;
    NSData *data = [message dataUsingEncoding:NSUTF8StringEncoding];
    CFErrorRef err = NULL;
    CFDataRef sig = SecKeyCreateSignature(priv, kSecKeyAlgorithmECDSASignatureMessageX962SHA256,
                                          (__bridge CFDataRef)data, &err);
    CFRelease(priv);                          /* nhả ref của caller */
    if (!sig) {
        if (err) {
            [LicenseCore diag:@"[LICENSE] PoP sign failed (%ld)", (long)CFErrorGetCode(err)];
            CFRelease(err);
        }
        return nil;
    }
    NSString *out = kdy_b64(CFBridgingRelease(sig));
    return out;
}

#pragma mark Server public key (embedded — PUBLIC, không nhạy cảm)

- (nullable SecKeyRef)serverPublicKey {
    if (_serverKey) {
        CFRetain(_serverKey);
        return _serverKey;
    }
    if (_serverKeyFailed) return NULL;

    /* PEM → base64 → SPKI 91 bytes → strip 26-byte header → raw point 65B */
    NSString *pem = kLicensePublicKeyPEM;
    if (![pem isKindOfClass:[NSString class]] || pem.length < 100) {
        [LicenseCore diag:@"[LICENSE] kLicensePublicKeyPEM chưa cấu hình"];
        _serverKeyFailed = YES;
        return NULL;
    }
    NSMutableString *b64 = [NSMutableString new];
    for (NSString *line in [pem componentsSeparatedByCharactersInSet:
            [NSCharacterSet newlineCharacterSet]]) {
        NSString *t = [line stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceCharacterSet]];
        if (t.length == 0) continue;
        if ([t hasPrefix:@"-----"]) continue;
        [b64 appendString:t];
    }
    NSData *der = kdy_b64decode(b64);
    if (!der || der.length != 91) {
        [LicenseCore diag:@"[LICENSE] public key DER sai định dạng (len=%lu)", (unsigned long)(der ? der.length : 0)];
        _serverKeyFailed = YES;
        return NULL;
    }
    /* SPKI P-256 cố định: 30 59 30 13 06 07 2A 86 48 CE 3D 02 01
     *                        06 08 2A 86 48 CE 3D 03 01 07 03 42 00 */
    static const uint8_t spkiHeader[26] = {
        0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x02, 0x01,
        0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00,
    };
    const uint8_t *bytes = (const uint8_t *)der.bytes;
    if (memcmp(bytes, spkiHeader, sizeof(spkiHeader)) != 0) {
        [LicenseCore diag:@"[LICENSE] public key không phải SPKI P-256"];
        _serverKeyFailed = YES;
        return NULL;
    }
    NSData *rawPoint = [NSData dataWithBytes:(bytes + 26) length:65];
    NSDictionary *attrs = @{
        (__bridge id)kSecAttrKeyType:       (__bridge id)kSecAttrKeyTypeECSECPrimeRandom,
        (__bridge id)kSecAttrKeyClass:      (__bridge id)kSecAttrKeyClassPublic,
        (__bridge id)kSecAttrKeySizeInBits: @256,
    };
    SecKeyRef key = SecKeyCreateWithData((__bridge CFDataRef)rawPoint,
                                         (__bridge CFDictionaryRef)attrs, NULL);
    if (!key) {
        [LicenseCore diag:@"[LICENSE] SecKeyCreateWithData public key thất bại"];
        _serverKeyFailed = YES;
        return NULL;
    }
    _serverKey = key;
    CFRetain(_serverKey);
    return _serverKey;
}

#pragma mark Keychain — license key

- (nullable NSString *)storedLicenseKey {
    NSDictionary *q = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService,
        (__bridge id)kSecAttrAccount: kKeychainAccount,
        (__bridge id)kSecReturnData:  @YES,
        (__bridge id)kSecMatchLimit:  (__bridge id)kSecMatchLimitOne,
    };
    CFTypeRef out = NULL;
    OSStatus st = SecItemCopyMatching((__bridge CFDictionaryRef)q, &out);
    if (st != errSecSuccess || !out) {
        if (out) CFRelease(out);
        return nil;
    }
    NSData *data = CFBridgingRelease(out);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

- (void)storeLicenseKey:(nullable NSString *)key {
    if (key.length == 0) {
        [self clearStoredLicenseKey];
        return;
    }
    NSDictionary *q = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService,
        (__bridge id)kSecAttrAccount: kKeychainAccount,
    };
    NSData *val = [key dataUsingEncoding:NSUTF8StringEncoding];
    OSStatus st = SecItemCopyMatching((__bridge CFDictionaryRef)q, NULL);
    if (st == errSecSuccess) {
        NSDictionary *upd = @{
            (__bridge id)kSecValueData: val,
            (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        };
        SecItemUpdate((__bridge CFDictionaryRef)q, (__bridge CFDictionaryRef)upd);
    } else {
        NSMutableDictionary *add = [q mutableCopy];
        add[(__bridge id)kSecValueData] = val;
        add[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;
        SecItemAdd((__bridge CFDictionaryRef)add, NULL);
    }
}

- (void)clearStoredLicenseKey {
    NSDictionary *q = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService,
        (__bridge id)kSecAttrAccount: kKeychainAccount,
    };
    SecItemDelete((__bridge CFDictionaryRef)q);
}

/* NSUserDefaults cũ (V1) → Keychain. Chạy 1 lần khi boot.
 * Đồng thời dọn marker cũ (vk4, dy9) — anti cũ đã bị loại bỏ. */
- (void)migrateLegacyDefaults {
    dispatch_sync(_stateQueue, ^{
        if (self.migrated) return;
        self.migrated = YES;
    });

    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];

    NSString *oldKey = [ud objectForKey:@"saved_license_key"];
    if ([oldKey isKindOfClass:[NSString class]] && oldKey.length > 0) {
        if (self.storedLicenseKey.length == 0) {
            [self storeLicenseKey:oldKey];
            [LicenseCore diag:@"[LICENSE] migrated legacy key → Keychain"];
        }
        [ud removeObjectForKey:@"saved_license_key"];
    }
    [ud removeObjectForKey:@"vk4"];   /* mirror q4 cũ */
    [ud removeObjectForKey:@"dy9"];   /* marker chết cũ — không dùng nữa */
    [ud synchronize];
}

#pragma mark Nonce + request builders

- (nullable NSString *)freshNonce {
    uint8_t buf[16];
    if (SecRandomCopyBytes(kSecRandomDefault, sizeof(buf), buf) != errSecSuccess) {
        return nil;
    }
    NSString *hex = kdy_hex(buf, sizeof(buf));
    [LicenseCore zeroBytes:buf length:sizeof(buf)];
    return hex;
}

- (nullable NSDictionary *)buildHelloRequest {
    return @{
        @"action": @"hello",
        @"pv":     @2,
        @"token":  kdy_package_token(),
    };
}

- (nullable NSDictionary *)buildAuthRequestForKey:(NSString *)key nonceS:(NSString *)nonceS {
    NSString *pubB64 = [self devicePublicKeyB64];
    NSString *nonceC = [self freshNonce];
    if (!pubB64 || !nonceC || nonceS.length == 0) return nil;

    UIDevice *dev = [UIDevice currentDevice];
    NSString *uuid = dev.identifierForVendor.UUIDString ?: @"";
    if (uuid.length == 0) return nil;

    int64_t ts = kdy_now_sec();
    /* KHỚP LicenseCrypto::verifyDevicePop trên server */
    NSString *popMsg = [NSString stringWithFormat:@"pop1|%@|%@|%lld", pubB64, nonceC, ts];
    NSString *pop = [self signPop:popMsg];
    if (!pop) return nil;

    return @{
        @"action":     @"auth",
        @"pv":         @2,
        @"token":      kdy_package_token(),
        @"key":        key,
        @"uuid":       [uuid lowercaseString],
        @"device_pub": pubB64,
        @"nonce_c":    nonceC,
        @"nonce_s":    nonceS,
        @"ts":         @(ts),
        @"pop":        pop,
    };
}

- (nullable NSDictionary *)buildRenewRequest {
    LicenseLease *l = self.currentLease;
    if (!l) return nil;
    NSString *nonceC = [self freshNonce];
    if (!nonceC) return nil;

    int64_t ts = kdy_now_sec();
    uint32_t seq = l.sequence;   /* server yêu cầu khớp seq hiện tại */
    NSString *popMsg = [NSString stringWithFormat:@"pop2|%@|%@|%lld|%u",
                        l.sessionId, nonceC, ts, (unsigned)seq];
    NSString *pop = [self signPop:popMsg];
    if (!pop) return nil;

    return @{
        @"action":     @"renew",
        @"pv":         @2,
        @"token":      kdy_package_token(),
        @"session_id": l.sessionId,
        @"nonce_c":    nonceC,
        @"ts":         @(ts),
        @"sequence":   @(seq),
        @"pop":        pop,
    };
}

- (nullable NSDictionary *)buildOffsetsRequest {
    /* Task 17 — giống renew nhưng PoP là pop3 (chứa action) để server
     * phân biệt chữ ký thiết bị dùng cho việc LẤY OFFSET. Server trả về
     * lease mới (sequence +1) kèm offsets trong chuỗi ĐÃ KÝ. */
    LicenseLease *l = self.currentLease;
    if (!l) return nil;
    NSString *nonceC = [self freshNonce];
    if (!nonceC) return nil;

    int64_t ts = kdy_now_sec();
    uint32_t seq = l.sequence;   /* khớp sequence server đang giữ */
    /* KHỚP server: 'pop3|offsets|' . sid . '|' . nonce . '|' . ts . '|' . seq */
    NSString *popMsg = [NSString stringWithFormat:@"pop3|offsets|%@|%@|%lld|%u",
                        l.sessionId, nonceC, ts, (unsigned)seq];
    NSString *pop = [self signPop:popMsg];
    if (!pop) return nil;

    return @{
        @"action":     @"offsets",
        @"pv":         @2,
        @"token":      kdy_package_token(),
        @"session_id": l.sessionId,
        @"nonce_c":    nonceC,
        @"ts":         @(ts),
        @"sequence":   @(seq),
        @"pop":        pop,
    };
}

#pragma mark Response verification

- (LicenseVerifyResult)verifyResponse:(NSDictionary *)json
                               action:(NSString *)action
                            sentNonce:(NSString *)sentNonce
                     thenMinSequence:(uint32_t)thenMinSequence
                    expectedLicenseFp:(nullable NSString *)expectedFp
                                 lease:(out LicenseLease *_Nullable *_Nullable)leaseOut
                               message:(out NSString *_Nullable *_Nullable)msgOut
                            forceExit:(out BOOL *)forceExitOut {
    if (leaseOut) *leaseOut = nil;
    if (msgOut) *msgOut = nil;
    if (forceExitOut) *forceExitOut = NO;
    self.lastVerifyFailHint = @"";   /* reset — chỉ Invalid mới ghi lại */
    if (![json isKindOfClass:[NSDictionary class]]) {
        self.lastVerifyFailHint = @"phản hồi không phải JSON của license";
        return LicenseVerifyInvalid;
    }

    /* 1. Lấy sig_input + signature */
    NSString *sigInput = json[@"sig_input"];
    NSString *sigB64   = json[@"signature"];
    if (![sigInput isKindOfClass:[NSString class]] || sigInput.length == 0) {
        self.lastVerifyFailHint = @"phản hồi thiếu sig_input (server cũ hoặc bị chặn?)";
        return LicenseVerifyInvalid;
    }
    if (![sigB64 isKindOfClass:[NSString class]] || sigB64.length == 0) {
        self.lastVerifyFailHint = @"phản hồi thiếu chữ ký";
        return LicenseVerifyInvalid;
    }
    NSData *sigDer = kdy_b64decode(sigB64);
    if (!sigDer || sigDer.length < 8 || sigDer.length > 200) {
        self.lastVerifyFailHint = @"độ dài chữ ký không hợp lệ";
        return LicenseVerifyInvalid;
    }

    /* 2. Verify chữ ký ECDSA P-256/SHA-256 (DER) trên sig_input */
    SecKeyRef pub = [self serverPublicKey];
    if (!pub) {
        self.lastVerifyFailHint = @"không nạp được public key server — kiểm tra kLicensePublicKeyPEM";
        return LicenseVerifyInvalid;
    }
    NSData *msgData = [sigInput dataUsingEncoding:NSUTF8StringEncoding];
    BOOL sigOK = SecKeyVerifySignature(pub, kSecKeyAlgorithmECDSASignatureMessageX962SHA256,
                                       (__bridge CFDataRef)msgData,
                                       (__bridge CFDataRef)sigDer, NULL);
    CFRelease(pub);                            /* nhả ref của caller */
    if (!sigOK) {
        self.lastVerifyFailHint = @"chữ ký server không khớp — server và app đang dùng hai khóa khác nhau";
        [LicenseCore diag:@"[LICENSE] signature INVALID (action=%@)", action];
        return LicenseVerifyInvalid;   /* chữ ký sai = phản hồi giả mạo */
    }

    /* 3. Parse sig_input → dict (client chỉ tin các trường này) */
    NSMutableDictionary *f = [NSMutableDictionary dictionary];
    for (NSString *pair in [sigInput componentsSeparatedByString:@"|"]) {
        NSRange eq = [pair rangeOfString:@"="];
        if (eq.location == NSNotFound) continue;
        NSString *k = [pair substringToIndex:eq.location];
        NSString *v = [pair substringFromIndex:eq.location + 1];
        if (k.length > 0) f[k] = v;
    }

    /* 4. Kiểm tra protocol + action + nonce echo */
    if (![f[@"pv"] isEqualToString:@"2"]) {
        self.lastVerifyFailHint = @"sai phiên bản protocol (pv≠2)";
        [LicenseCore diag:@"[LICENSE] protocol version mismatch"];
        return LicenseVerifyInvalid;
    }
    if (![f[@"action"] isEqualToString:action]) {
        self.lastVerifyFailHint = [NSString stringWithFormat:@"sai action phản hồi (%@)", f[@"action"] ?: @"?"];
        [LicenseCore diag:@"[LICENSE] action mismatch: %@ != %@", f[@"action"], action];
        return LicenseVerifyInvalid;
    }
    NSString *nonceEcho = f[@"nonce_c"];
    if (sentNonce.length > 0) {
        if (!nonceEcho || !kdy_cteq(nonceEcho, sentNonce)) {
            self.lastVerifyFailHint = @"nonce không khớp (nghi ngờ replay)";
            [LicenseCore diag:@"[LICENSE] nonce echo mismatch (replay?)"];
            return LicenseVerifyInvalid;   /* replay / response sai request */
        }
    }

    /* 5. server_time hợp lệ + tính offset đồng hồ */
    int64_t serverTime = [f[@"server_time"] longLongValue];
    int64_t localNow = kdy_now_sec();
    if (serverTime < 1577836800LL /* 2020-01-01 */) {
        self.lastVerifyFailHint = @"server_time không hợp lệ";
        return LicenseVerifyInvalid;
    }
    if (llabs(serverTime - localNow) > kMaxReasonableDrift) {
        self.lastVerifyFailHint = [NSString stringWithFormat:@"đồng hồ thiết bị lệch %lld giây so với server — hãy bật Cài đặt → Cài đặt chung → Ngày & Giờ → Tự động",
                                   (long long)llabs(serverTime - localNow)];
        [LicenseCore diag:@"[LICENSE] server_time lệch bất thường"];
        return LicenseVerifyInvalid;
    }
    int64_t offset = serverTime - localNow;

    /* 6. Status */
    NSString *status = f[@"status"] ?: @"0";

    if (![status isEqualToString:@"1"]) {
        /* Server ký từ chối dứt khoát — tin (đây là authority) */
        if (msgOut) {
            *msgOut = [f[@"message"] isKindOfClass:[NSString class]] ? f[@"message"] : @"Key không hợp lệ";
        }
        if (forceExitOut) {
            *forceExitOut = [f[@"force_exit"] isEqualToString:@"1"];
        }
        return LicenseVerifyRejected;
    }

    /* 7a. hello: chỉ cần nonce_s + contact + maintenance (không có lease) */
    if ([action isEqualToString:@"hello"]) {
        NSString *nonceS = f[@"nonce_s"];
        if (!kdy_isHexLower(nonceS, 32)) {
            self.lastVerifyFailHint = @"challenge nonce_s sai định dạng";
            [LicenseCore diag:@"[LICENSE] hello: nonce_s sai định dạng"];
            return LicenseVerifyInvalid;
        }
        LicenseLease *info = [[LicenseLease alloc] init];
        info.nonceS = nonceS;
        info.contact = [f[@"contact"] isKindOfClass:[NSString class]] ? f[@"contact"] : @"";
        info.maintenance = ([f[@"maintenance"] integerValue] == 1);
        info.serverTime = serverTime;
        info.clockOffset = offset;
        if (leaseOut) *leaseOut = info;
        return LicenseVerifyGranted;
    }

    /* 7. Lease bắt buộc phải có đủ + đúng format */
    NSString *sessionId = f[@"session_id"];
    NSString *licenseFp = f[@"license_fp"];
    NSString *devBind   = f[@"device_binding"];
    if (!kdy_isHexLower(sessionId, 32) || !kdy_isHexLower(licenseFp, 16)
        || !kdy_isHexLower(devBind, 16)) {
        self.lastVerifyFailHint = @"trường lease sai định dạng";
        [LicenseCore diag:@"[LICENSE] lease field format sai"];
        return LicenseVerifyInvalid;
    }

    /* 8. device_binding phải là của chính thiết bị này */
    NSString *myBind = [self deviceBindingHex];
    if (!myBind || !kdy_cteq(devBind, myBind)) {
        self.lastVerifyFailHint = @"device_binding không khớp thiết bị này";
        [LicenseCore diag:@"[LICENSE] device_binding mismatch"];
        return LicenseVerifyInvalid;
    }

    /* 9. license_fp phải khớp lease trước đó (renew) */
    if (expectedFp.length > 0 && !kdy_cteq(licenseFp, expectedFp)) {
        self.lastVerifyFailHint = @"license_fp không khớp phiên trước";
        [LicenseCore diag:@"[LICENSE] license_fp mismatch"];
        return LicenseVerifyInvalid;
    }

    /* 10. sequence đơn điệu */
    uint32_t seq = 0;
    if (![f[@"sequence"] isKindOfClass:[NSString class]]
        || sscanf(((NSString *)f[@"sequence"]).UTF8String, "%u", &seq) != 1
        || seq <= thenMinSequence) {
        self.lastVerifyFailHint = @"sequence không hợp lệ / cũ";
        [LicenseCore diag:@"[LICENSE] sequence không hợp lệ / cũ"];
        return LicenseVerifyInvalid;
    }

    /* 11. Lease còn thời hạn (theo giờ server-aligned + dung sai) */
    int64_t issuedAt  = [f[@"issued_at"] longLongValue];
    int64_t expiresAt = [f[@"expires_at"] longLongValue];
    int64_t leaseTtl  = [f[@"lease_ttl"] longLongValue];
    int64_t graceTtl  = [f[@"grace_ttl"] longLongValue];
    if (issuedAt <= 0 || expiresAt <= issuedAt || leaseTtl <= 0 || graceTtl < 0
        || expiresAt > localNow + 86400) {
        self.lastVerifyFailHint = @"thời gian lease không hợp lệ";
        [LicenseCore diag:@"[LICENSE] lease time không hợp lệ"];
        return LicenseVerifyInvalid;
    }
    if ((expiresAt + kClockSkewLeaseSec) <= (localNow + offset)) {
        self.lastVerifyFailHint = @"lease đã hết hạn lúc nhận";
        [LicenseCore diag:@"[LICENSE] lease đã hết hạn lúc nhận"];
        return LicenseVerifyInvalid;
    }

    /* 12. Permissions: nếu server khai báo, esp phải được phép */
    NSDictionary *perms = nil;
    NSString *permRaw = f[@"permissions"];
    if ([permRaw isKindOfClass:[NSString class]] && permRaw.length > 0) {
        NSData *pd = [permRaw dataUsingEncoding:NSUTF8StringEncoding];
        id parsed = [NSJSONSerialization JSONObjectWithData:pd options:0 error:nil];
        if ([parsed isKindOfClass:[NSDictionary class]]) perms = parsed;
    }

    /* 13. Task 17 — offset payload: chỉ tin chuỗi offsets/game_version
     * đọc TỪ SIG_INPUT ĐÃ KÝ (bên ngoài envelope có thể bị MITM sửa). */
    NSString *offsetsJSON = nil;
    NSString *gameVersion = nil;
    if ([f[@"offsets"] isKindOfClass:[NSString class]]
        && ((NSString *)f[@"offsets"]).length > 2) {
        offsetsJSON = (NSString *)f[@"offsets"];
    }
    if ([f[@"game_version"] isKindOfClass:[NSString class]]) {
        gameVersion = (NSString *)f[@"game_version"];
    }

    LicenseLease *lease = [[LicenseLease alloc] init];
    lease.sessionId     = sessionId;
    lease.issuedAt      = issuedAt;
    lease.expiresAt     = expiresAt;
    lease.sequence      = seq;
    lease.licenseFp     = licenseFp;
    lease.deviceBinding = devBind;
    lease.serverTime    = serverTime;
    lease.clockOffset   = offset;
    lease.leaseTtl      = leaseTtl;
    lease.graceTtl      = graceTtl;
    lease.expiry        = [f[@"expiry"] isKindOfClass:[NSString class]] ? f[@"expiry"] : @"";
    lease.daysLeft      = [f[@"days_left"] integerValue];
    lease.contact       = [f[@"contact"] isKindOfClass:[NSString class]] ? f[@"contact"] : @"";
    lease.permissions   = perms;
    lease.offsetsJSON   = offsetsJSON;    /* Task 17 */
    lease.gameVersion   = gameVersion;    /* Task 17 */

    if (leaseOut) *leaseOut = lease;
    return LicenseVerifyGranted;
}

#pragma mark Utilities

+ (void)zeroBytes:(uint8_t *)buf length:(size_t)len {
    if (buf == NULL || len == 0) return;
    volatile uint8_t *p = buf;
    for (size_t i = 0; i < len; i++) p[i] = 0;
}

+ (void)diag:(NSString *)format, ... {
#if DEBUG
    va_list args;
    va_start(args, format);
    NSString *msg = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    NSLog(@"%@", msg);
#else
    (void)format;
#endif
}

@end
