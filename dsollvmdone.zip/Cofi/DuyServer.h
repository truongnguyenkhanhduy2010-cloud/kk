//
//  DuyServer.h — License Core V2 (server-authoritative signed lease).
//
//  Client KHÔNG tự quyết định license hợp lệ. Client chỉ:
//    1. giữ cặp khóa thiết bị (Secure Enclave, private key không rời máy),
//    2. gửi request kèm nonce + proof-of-possession,
//    3. VERIFY chữ ký ECDSA P-256 của server trên mọi phản hồi,
//    4. giữ lease ngắn hạn do server cấp — hết lease + grace là khóa.
//
//  KHÔNG có master secret / private key nào của server nằm trong client.
//  Chỉ nhúng PUBLIC KEY (kLicensePublicKeyPEM trong HeaderAPI.h).
//
//  File này KHÔNG chứa UI — api/khanhduy.mm điều khiển luồng + gate.
//

#ifndef DuyServer_h
#define DuyServer_h

#import <Foundation/Foundation.h>
#import <Security/Security.h>

NS_ASSUME_NONNULL_BEGIN

/* ------------------------- Security state machine ---------------------- */
/* Mọi transition phải qua -transitionTo: — transition bất hợp pháp bị
 * reject (ví dụ BOOT → AUTHORIZED là BẤT HỢP PHÁP, phải đi qua
 * CHALLENGE → AUTHENTICATING). Không dùng 1 BOOL duy nhất. */
typedef NS_ENUM(uint8_t, LicenseState) {
    LicenseStateBoot = 0,
    LicenseStateNetInit,        /* đang gọi hello */
    LicenseStateChallenge,      /* đã có nonce_s — chờ key */
    LicenseStateKeyPending,     /* chờ người dùng nhập key */
    LicenseStateAuthenticating, /* đang auth/re-auth */
    LicenseStateAuthorized,     /* lease hợp lệ đang chạy */
    LicenseStateRenewing,       /* đang gia hạn lease */
    LicenseStateGrace,          /* mất mạng — đang trong grace */
    LicenseStateRevoked,        /* server thu hồi key */
    LicenseStateExpired,        /* key hết hạn */
    LicenseStateLocked,         /* session hết hạn / bị thu hồi */
    LicenseStateShutdown,
};

NSString *LicenseStateName(LicenseState s);

/* ------------------------------ Verify result --------------------------- */
typedef NS_ENUM(uint8_t, LicenseVerifyResult) {
    LicenseVerifyInvalid  = 0,  /* chữ ký/protocol sai → KHÔNG tin (fail-closed) */
    LicenseVerifyRejected = 1,  /* server ký từ chối dứt khoát (invalid/expired/...) */
    LicenseVerifyGranted  = 2,  /* server ký cấp lease hợp lệ */
};

/* -------------------------------- Lease --------------------------------- */
@interface LicenseLease : NSObject

@property (nonatomic, copy, readonly) NSString *sessionId;      /* hex 32 */
@property (nonatomic, assign, readonly) int64_t issuedAt;      /* unix sec */
@property (nonatomic, assign, readonly) int64_t expiresAt;     /* unix sec */
@property (nonatomic, assign, readonly) uint32_t sequence;
@property (nonatomic, copy, readonly) NSString *licenseFp;     /* hex 16 */
@property (nonatomic, copy, readonly) NSString *deviceBinding; /* hex 16 */
@property (nonatomic, assign, readonly) int64_t serverTime;
@property (nonatomic, assign, readonly) int64_t clockOffset;   /* server - local */
@property (nonatomic, assign, readonly) int64_t leaseTtl;      /* giây */
@property (nonatomic, assign, readonly) int64_t graceTtl;      /* giây */
@property (nonatomic, copy, readonly) NSString *expiry;        /* hiển thị */
@property (nonatomic, assign, readonly) NSInteger daysLeft;    /* hiển thị */
@property (nonatomic, copy, readonly) NSString *contact;
@property (nonatomic, strong, readonly, nullable) NSDictionary *permissions; /* vd {"esp":1} */

/* Task 17 — offset game do server cấp: chỉ khác nil trong phản hồi
 * action=offsets ĐÃ verify chữ ký. offsetsJSON là chuỗi
 * {"Name":"0x...",...} — do OffsetRegistry parse + áp. */
@property (nonatomic, copy, readonly, nullable) NSString *offsetsJSON;
@property (nonatomic, copy, readonly, nullable) NSString *gameVersion;

@property (nonatomic, copy, readonly, nullable) NSString *nonceS;      /* challenge server (hello) */
@property (nonatomic, assign, readonly) BOOL maintenance;      /* hello: server đang bảo trì */
@property (nonatomic, assign, readonly) BOOL forceExit;        /* rejected: server yêu cầu thoát */

- (BOOL)isValidNowWithClockSkew:(int64_t)skew;   /* expiresAt + skew còn hiệu lực */

@end

/* ------------------------------ LicenseCore ----------------------------- */
@interface LicenseCore : NSObject

+ (instancetype)sharedCore;

/* State machine — thread-safe (serial queue nội bộ) */
@property (nonatomic, assign, readonly) LicenseState state;
- (BOOL)transitionTo:(LicenseState)to;
- (BOOL)ensureAuthorized;   /* FIX lockout: ép về AUTHORIZED sau Granted (hồi phục qua chuỗi trung gian) */
- (BOOL)sessionUsable;   /* Authorized && lease còn hạn (theo giờ server-aligned + grace) */
- (BOOL)leaseAliveIgnoringState;   /* FIX lockout: lease đã verify còn hạn bất chấp state — chỉ dùng hồi phục gate_dismiss */

/* Đồng hồ: local + offset đã hiệu chỉnh theo server_time ký số */
- (int64_t)serverAlignedNow;

/* Device identity — keypair Secure Enclave (fallback software key) */
- (nullable NSString *)devicePublicKeyB64;                  /* base64 raw 65B point */
- (nullable NSString *)signPop:(NSString *)message;         /* DER sig → base64 */
- (nullable NSString *)deviceBindingHex;                    /* 16 hex — khớp server */

/* Server public key (từ kLicensePublicKeyPEM) */
- (nullable SecKeyRef)serverPublicKey CF_RETURNS_RETAINED;

/* Keychain: license key (không dùng NSUserDefaults cho dữ liệu nhạy cảm) */
- (nullable NSString *)storedLicenseKey;
- (void)storeLicenseKey:(nullable NSString *)key;
- (void)clearStoredLicenseKey;
- (void)migrateLegacyDefaults;   /* NSUserDefaults cũ → Keychain (chạy 1 lần) */

/* Request builders — mỗi lần gọi sinh nonce MỚI (chống replay) */
- (nullable NSDictionary *)buildHelloRequest;
- (nullable NSDictionary *)buildAuthRequestForKey:(NSString *)key
                                         nonceS:(NSString *)nonceS;
- (nullable NSDictionary *)buildRenewRequest;

/* Task 17 — request fetch offset: giống renew (session + sequence) nhưng
 * PoP là pop3 (có action trong chuỗi ký) và không dùng để mở gate. */
- (nullable NSDictionary *)buildOffsetsRequest;

/* Response verification — trả về mã kết quả + lease/message tương ứng.
 * forceExitOut = server ký yêu cầu client thoát (force_exit=1). */
- (LicenseVerifyResult)verifyResponse:(NSDictionary *)json
                               action:(NSString *)action
                            sentNonce:(NSString *)sentNonce
                     thenMinSequence:(uint32_t)thenMinSequence
                    expectedLicenseFp:(nullable NSString *)expectedFp
                                 lease:(out LicenseLease *_Nullable *_Nullable)leaseOut
                               message:(out NSString *_Nullable *_Nullable)msgOut
                            forceExit:(out BOOL *)forceExitOut;

/* Lease hiện tại (in-memory; không bao giờ tin persisted lease như verified) */
- (nullable LicenseLease *)currentLease;
- (void)acceptLease:(LicenseLease *)lease;
- (void)clearLease;

/* Lần verify gần nhất trả về Invalid: lý do NGẮN bằng tiếng Việt để UI
 * hiển thị cho người dùng (RELEASE luôn có giá trị, không chỉ DEBUG).
 * Rỗng nếu lần verify gần nhất hợp lệ. */
@property (nonatomic, copy, readonly, nullable) NSString *lastVerifyFailHint;

/* Dọn buffer nhạy cảm best-effort */
+ (void)zeroBytes:(uint8_t *)buf length:(size_t)len;

/* Log chẩn đoán an toàn (DEBUG only — không log key/session) */
+ (void)diag:(NSString *)format, ... NS_FORMAT_FUNCTION(1, 2);

@end

/* Boundary hook: gọi khi 1 tính năng nhạy cảm cần authorization hợp lệ
 * nhưng không có (vd ESP activation) — sẽ hiện lại màn khóa + auth lại.
 * extern "C" BẮT BUỘC: hàm được gọi từ file .m (C linkage) nhưng định
 * nghĩa nằm trong .mm — thiếu extern "C" sẽ bị C++ name-mangling
 * (__Z19LicenseReassertGatev) → linker không tìm thấy _LicenseReassertGate. */
#ifdef __cplusplus
extern "C" {
#endif
void LicenseReassertGate(void);

/* Task 18 — KEY CHECK TẠI THỜI ĐIỂM BẤM "Activate ESP": hỏi server TƯƠI
 * (PoP pop3 + session + key status trong DB). Server chỉ kèm offset vào
 * lease ĐÃ KÝ khi key còn đúng. Kết quả trả về ESPInstaller qua
 * notification (main thread):
 *   kdy_offsets_check_ok   — key đúng, offset đã được cấp (userInfo: version)
 *   kdy_offsets_check_deny — key sai / revoked / expired / maintenance…
 *                            (userInfo: reason đã dịch tiếng Việt)
 * Cùng chuẩn mã hoá/điện toán với connect/auth/renew: HTTPS + chữ ký
 * ECDSA P-256 trong payload (offset nằm TRONG sig_input đã ký). */
void LicenseActivateESPCheck(void);
extern NSString *kdy_offsets_check_ok;
extern NSString *kdy_offsets_check_deny;
#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END

#endif /* DuyServer_h */
